<h1>VARIÁVEIS</h1>

## DECLARAÇÃO DE VARIÁVEIS
## ESCOPO
### GLOBAL
aaaaaaaaa
- [x] ddddd
- [x] ccccc
- [x] aaaaa
- [ ] bbbbb

``` javascript
if (pedro === 'legal')
```
### BLOCO
### FUNÇÃO

